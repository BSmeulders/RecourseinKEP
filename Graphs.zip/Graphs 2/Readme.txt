Formatting of the graph files.

First lines give the number of pairs and number of non-directed donors (referred to collectively as node).
Next, one line for each node with the node ID, and then the probability that the node fails.
Finally, a list of arcs, one line per arc. 
	First, within brackets, the start and endpoint (donor of startpoint can donate to recipient in endpoint).
	Second, the failure probability of the arc.
	Third, the value/weight of the arc.